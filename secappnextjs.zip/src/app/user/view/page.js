import React from 'react'

function Page() {
    return (
        <div>
            <h1>View Users</h1>
            <table>
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>user1</td>
                        <td>user@user.com</td>
                        <td>user</td>
                    </tr>
                    <tr>
                        <td>user2</td>
                        <td>user2@user.com</td>
                        <td>user2</td>
                    </tr>
                </tbody>
            </table>
        </div>
    )
}

export default Page
