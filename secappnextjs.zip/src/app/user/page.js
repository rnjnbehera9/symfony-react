import React from 'react'

function Page() {
    return (
        <div>
            <h1>User Page</h1>
            <p>This is the User page</p>
        </div>
    )
}

export default Page
