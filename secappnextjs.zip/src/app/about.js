import React from 'react'

function About() {
    return (
        <h1>About US</h1>
    )
}

export default About
