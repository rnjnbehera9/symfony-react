
export default function contactus() {
    return (
      <main>
        <h1>This is contact us page</h1>
      </main>
    );
  }
  