
export default function aboutus() {
    return (
      <main>
        <h1>This is about us page</h1>
      </main>
    );
  }
  