import React from 'react'

function Page() {
    return (
        <div>
            <h1>Admin Page</h1>
            <p>This is the admin page</p>
        </div>
    )
}

export default Page
