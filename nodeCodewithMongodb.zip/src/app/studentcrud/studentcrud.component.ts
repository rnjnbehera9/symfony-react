import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { NgFor } from "@angular/common";
@Component({
  selector: 'app-studentcrud',
  standalone: true,
  imports: [    
    NgFor,
    FormsModule],
  templateUrl: './studentcrud.component.html',
  styleUrl: './studentcrud.component.css'
})
export class StudentcrudComponent {
  name: string = '';  // Add the missing property
  tech: string = '';  // Add the missing property
}
